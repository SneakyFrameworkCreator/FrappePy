import random
import numpy
pi_num = numpy.pi_num
import string
def add_int(num1,num2):
    cnum1 = int(num1)
    cnum2 = int(num2)
    return cnum1+cnum2
def minus_int(num1,num2):
    cnum1 = int(num1)
    cnum2 = int(num2)
    return cnum1+cnum2
def divide_int(num1,num2):
    cnum1 = int(num1)
    cnum2 = int(num2)
    return cnum1/cnum2
def multiply_int(num1,num2):
    cnum1 = int(num1)
    cnum2 = int(num2)
    return cnum1*cnum2
#######################################
#______ _             _       
#|  ___| |           | |      
#| |_  | | ___   __ _| |_ ___ 
#|  _| | |/ _ \ / _` | __/ __|
#| |   | | (_) | (_| | |_\__ \
#\_|   |_|\___/ \__,_|\__|___/
########################################                             
                             
def add_float(num1,num2):
    cnum1 = float(num1)
    cnum2 = float(num2)
    return cnum1+cnum2
def minus_float(num1,num2):
    cnum1 = float(num1)
    cnum2 = float(num2)
    return cnum1+cnum2
def divide_float(num1,num2):
    cnum1 = float(num1)
    cnum2 = float(num2)
    return cnum1/cnum2
def multiply_float(num1,num2):
    cnum1 = float(num1)
    cnum2 = float(num2)
    return cnum1*cnum2